---
name: quote-follow-up
description: Reads a list of open quotes or estimates and tells the owner who needs a follow-up today, who can wait and who to close out, then drafts a short follow-up for each in the owner's voice. Use this whenever someone pastes or attaches a list of quotes, estimates, proposals or leads and asks who to chase, asks for follow-up or nudge messages, mentions quotes going quiet, or runs a weekly follow-up routine, even if they only say "here's my quotes list".
---

# Quote Follow-Up

Quotes go quiet because following up is nobody's favorite job, and most owners have no routine for it. This skill turns a list of open quotes into a short plan and a set of drafts. The owner reads them, fixes them and sends them from their own email. Nothing here sends anything.

## What you need

**The list.** Pasted text, a spreadsheet or a CSV. Useful columns are first name, the job, date quoted, date of last contact, what they last said, and status. Work with whatever is there. If the date quoted is missing for most rows, ask for it, because the plan depends on it.

**Today's date.** If you do not know it for certain, ask. Guessing the date makes every "days since" figure wrong.

**Their voice.** Use the business brief or voice notes in this project if there are any. If there are none, write plainly and briefly and mention once that a business brief would make the drafts sound more like them.

If the list contains full names, addresses, phone numbers or email addresses, use first names only in what you write back, and suggest they keep those columns out next time. The follow-up plan does not need them.

## Step 1: Sort the list

Put every open quote into one of four groups and give one line of reasoning for each person.

- **Answer first.** The customer asked a question that has not been answered. These come before any nudge, because the delay is on the business.
- **Follow up today.** No reply, and it has been at least three working days since the quote or the last contact.
- **Wait.** Quoted in the last couple of working days, or the customer said when they would decide and that date has not passed.
- **Close out.** Two follow-ups have already gone unanswered, or it has been more than about four weeks. One polite closing note, then stop.

These timings are a starting rhythm. If the owner has told you theirs, use theirs.

Show the result as a table: name, job, days since last contact, group, reason.

## Step 2: Draft

Write one message for each person in the first, second and fourth groups.

- Three sentences at most. A follow-up that takes a minute to read gets left for later.
- Name their job specifically, so it is plainly not a mass message.
- For "answer first", answer the question if the list gives you the answer. If it does not, write `[ADD: your answer]` and never guess at prices, dates or availability.
- End with one easy question they can answer in a word or two.
- For "close out", be warm and leave the door open, with no guilt and no pressure.
- Offer no discounts, deadlines or promises unless the owner has given them to you.

Put each draft under the person's first name so it is easy to copy.

## Step 3: Hand back

End with two lines: a reminder to check names and dates before sending, and a prompt to update the list afterwards (new date of last contact, new status) so next week's run is accurate.

If the owner asks you to send the messages, explain that this skill only drafts, and that sending from their own email is what keeps the follow-up personal.
