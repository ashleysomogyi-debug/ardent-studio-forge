---
name: business-brief-builder
description: Interviews a small business owner and writes a one-page business brief that makes every later AI answer sound like it knows the business. Use this whenever someone asks to build, write, set up or update a business brief, business profile, "about my business" page or context document for their AI, says the AI's answers sound generic, or says they are tired of re-explaining their business in every chat, even if they never say the word "brief".
---

# Business Brief Builder

A new chat knows almost nothing about the person's business, so it guesses, and the guesses sound like any business in the country. A one-page brief saved where every chat can see it fixes most of that. Your job is to get that page written with as little effort from the owner as possible.

The person is usually a busy owner who is not technical. Keep questions short, in plain English, and never ask for anything they would need to look up.

## How to run it

### 1. Check for a head start

If they have pasted or attached anything already (a website page, a price list, an old "about us"), read it first and skip the questions it already answers. Tell them in one line what you took from it.

### 2. Interview, one question at a time

Ask no more than ten questions. Ask one, wait for the answer, then ask the next. A wall of ten questions gets abandoned; one at a time feels like a conversation and takes about five minutes.

Cover these, in this order, skipping any you already know:

1. The business name and the town or area it serves.
2. What they sell, in their own words.
3. Who buys it. A typical customer, not a market segment.
4. The three or four questions customers ask most.
5. How they quote or price. The method, not the numbers, unless they volunteer numbers.
6. What happens after someone says yes: the usual steps and timing.
7. How they like to sound with customers. Offer two or three choices if they hesitate, for example "friendly and brief" or "formal and detailed".
8. Words, promises or topics they never want used on their behalf.
9. How they sign off, and the name customers know them by.
10. Anything they wish every new employee knew on day one.

If an answer is thin, ask one short follow-up and move on. Do not push past ten questions in total. A brief that exists beats a perfect one that never gets finished.

### 3. Offer the voice step

Ask whether they can paste two or three things they wrote themselves that got a good response, such as emails to customers. Ask them to remove customer names first. If they do, describe how they write in five short bullets: sentence length, tone, words they use, words they avoid, how they sign off. If they would rather skip it, move on without comment.

### 4. Write the brief

Use this structure. Keep the whole thing under 400 words so it fits in a project's instructions without crowding out the actual work.

```
# About [business name]

**What we do:** one or two sentences.
**Where:** town or service area.
**Who buys from us:** one or two sentences.

## What customers ask most
- question, with the short true answer

## How we quote
A few plain sentences.

## What happens after yes
The usual steps and timing.

## How we sound
Three to five bullets. Include the voice notes if step 3 was done.

## Never say
- the list from question 8

## Sign-off
The name and closing they use.
```

Write only what they told you. If something is missing, leave a line reading `[ADD: what is missing]` instead of filling the gap with something plausible. An invented detail in this document gets repeated in every answer that follows, which is worse than a blank.

### 5. Hand it over

Give them the brief, ask them to read it once and correct anything wrong, then tell them where it goes: in Claude, create a project named after the business, choose "Set project instructions", paste the brief and save. Work chats started inside that project will then begin with it.

If they come back later with a correction ("it keeps saying we do weekend work, we don't"), update the matching line and return the full revised brief so they can paste it over the old one.

## What to keep out

Leave out anything the owner would not want every future chat to see or repeat: customer names and contact details, bank or card details, passwords, and staff personal information. If they offer any of these, say you are leaving it out and why.
