---
name: sounds-like-me
description: Checks a draft email, message, post or letter against the owner's own writing and marks the lines that read like a chatbot wrote them, then offers a version that sounds like the owner. Use this whenever someone asks whether a draft sounds like them, sounds like AI, sounds robotic or generic, asks to "make this sound like me", or is about to send something an AI drafted to a customer, even if they only say "can you look this over before I send it".
---

# Sounds Like Me

Customers can often tell when a message came straight out of a chatbot, and the owner loses the personal touch that makes a small business worth buying from. This skill is the check before sending. It marks what reads as machine-written, lists what needs verifying, and offers a fix, without inventing anything.

## What you need first

You need to know how this person writes. Look, in this order, for:

1. Voice notes or a business brief in this project's instructions or files.
2. Samples they have pasted in this chat.

If you have neither, ask for two or three things they wrote themselves, with customer names removed, before reviewing anything. Checking a draft against a voice you have not seen produces confident nonsense. If they cannot supply samples right now, say you will check for common machine patterns only, and that the voice match will be rough.

When samples arrive, sum up their voice in five short bullets (sentence length, tone, words they use, words they avoid, sign-off) and suggest they add those bullets to their business brief so they never have to paste samples again.

## The review

Return three short sections, in this order.

### 1. Lines that read like a chatbot

Quote each line and say why in a few words. Look for:

- Openers nobody says aloud: "I hope this message finds you well", "Thank you for reaching out".
- Stock reassurance: "rest assured", "please do not hesitate", "we sincerely apologize for any inconvenience".
- Generic praise or filler: "valued customer", "a wide range of high-quality services".
- Adjectives in threes, and sentences that could be about any business.
- A closing line that restates the message.
- Anything out of step with their voice notes: longer sentences than they write, a formal tone when they are casual, a sign-off they do not use.

If nothing reads as machine-written, say so plainly. Do not find problems to justify the review.

### 2. Facts to check before sending

List every name, price, date, time, quantity and promise in the draft. Do not say whether they are correct. You cannot know, and a drafting AI fills gaps with plausible guesses. The owner checks these against their own records.

### 3. A version that sounds like them

Rewrite the draft in their voice. Keep every fact and every commitment exactly as given. Make it shorter if you can.

Where the message would be better with a detail only the owner knows (what was discussed on site, something the customer mentioned), do not make one up. Insert `[ADD: a detail only you know, for example ...]` so they can fill it in. One real detail does more for a message than any amount of polish.

## Limits

This skill reviews wording. It does not decide whether the message should be sent, and it does not send anything. If the draft makes a promise that looks risky, such as a refund, a deadline or a price, mention it once in section 2 and leave the decision to the owner.
